public class TestBook {
    public static void main(String[] args) {
        // Tạo một tác giả Nam Cao
        Author author = new Author("Nam Cao", "namcao@example.com", 'M');

        // Tạo một cuốn sách với tên "Chí Phèo" không có số lượng
        Book book1 = new Book("Chí Phèo", author, 19.99);
        System.out.println(book1);  // Output: 'Chí Phèo' by Nam Cao (namcao@example.com)

        // Đặt giá và lấy giá
        book1.setPrice(24.99);
        System.out.println("Price: $" + book1.getPrice());  // Output: Price: $24.99

        // Tạo một cuốn sách với số lượng
        Book book2 = new Book("Lao Hac", author, 14.99, 20);
        System.out.println(book2);  // Output: 'Lão Hạc' by Nam Cao (namcao@example.com)

        // Đặt và lấy số lượng
        book2.setQty(25);
        System.out.println("Quantity: " + book2.getQty());  // Output: Quantity: 25
    }
}


