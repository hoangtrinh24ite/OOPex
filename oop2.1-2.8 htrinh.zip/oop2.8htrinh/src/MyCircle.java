public class MyCircle {
    private MyPoint center ;
    private int radius;

    public MyCircle() {
        this.center = new MyPoint(0,0);
        this.radius = 0;
    }
    public MyCircle(int x, int y, int radius) {
        this.center = new MyPoint(x, y);
        this.radius = radius;
    }
    // Constructor with MyPoint and radius
    public MyCircle(MyPoint center, int radius) {
        this.center = center;
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    // Getter and setter for center
    public MyPoint getCenter() {
        return center;
    }

    public void setCenter(MyPoint center) {
        this.center = center;
    }

    // Getter and setter for center X coordinate
    public int getCenterX() {
        return center.getX();
    }

    public void setCenterX(int x) {
        this.center.setX(x);
    }

    // Getter and setter for center Y coordinate
    public int getCenterY() {
        return center.getY();
    }

    public void setCenterY(int y) {
        this.center.setY(y);
    }

    // Getter for center coordinates as an array
    public int[] getCenterXY() {
        return new int[] { getCenterX(),getCenterY()};
    }

    // Setter for center coordinates
    public void setCenterXY(int x, int y) {
        this.center.setX(x);
        this.center.setY(y);
    }

    // Override toString method
    public String toString() {
        return "MyCircle [center=" + center + ", radius=" + radius + "]";
    }

    // Method to calculate area
    public double getArea() {
        return Math.PI * radius * radius;
    }

    // Method to calculate circumference
    public double getCircumference() {
        return 2 * Math.PI * radius;
    }

    // Method to calculate distance to another circle
    public double distance(MyCircle another) {
        //int xDiff=getCenterX() - another.center.getX();
        //int yDiff=getCenterY() - another.center.getY();
        //return Math.sqrt(xDiff*xDiff + yDiff*yDiff);
        return center.distance(another.center);
    }
}
